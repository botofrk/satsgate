// AIPP Extension Background Service Worker (Manifest V3)

chrome.runtime.onInstalled.addListener(() => {
  console.log('[aipp.dev] Chrome Extension installed successfully.');

  // Create right-click context menu for instant element locking
  chrome.contextMenus.create({
    id: 'aipp-lock-selection',
    title: '🏷️ Create Smart Price Tag for this ($1.00)',
    contexts: ['all']
  });
});

// Handle Context Menu clicks
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === 'aipp-lock-selection' && tab?.id) {
    // Prevent injecting into chrome:// internal pages
    if (tab.url && (tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://') || tab.url.startsWith('about:'))) {
      return;
    }
    try {
      await chrome.scripting.insertCSS({
        target: { tabId: tab.id },
        files: ['content/content.css']
      });
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content/content.js']
      });
    } catch (_) {}
    chrome.tabs.sendMessage(tab.id, { action: 'START_PICKER', price: 0.10 });
  }
});
