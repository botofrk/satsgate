// AIPP Content Script — DOM Picker & L402 Autopay Detect
(function() {
  let isPickerActive = false;
  let currentHoverTarget = null;
  let targetLockPrice = 0.10;

  // Listen for messages from Popup
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'START_PICKER') {
      targetLockPrice = request.price || 0.10;
      enablePicker();
      sendResponse({ status: 'PICKER_ENABLED' });
    }
  });

  function enablePicker() {
    isPickerActive = true;
    document.body.classList.add('aipp-picker-active');
    showToast(`🎯 AIPP Picker Active: Hover & Click any element to lock ($${targetLockPrice.toFixed(2)}). Press ESC to cancel.`);
    document.addEventListener('mouseover', handleMouseOver, true);
    document.addEventListener('mouseout', handleMouseOut, true);
    document.addEventListener('click', handleClick, true);
    document.addEventListener('keydown', handleKeyDown, true);
  }

  function disablePicker() {
    isPickerActive = false;
    document.body.classList.remove('aipp-picker-active');
    hideToast();
    if (currentHoverTarget) {
      currentHoverTarget.classList.remove('aipp-picker-hover');
      currentHoverTarget = null;
    }
    document.removeEventListener('mouseover', handleMouseOver, true);
    document.removeEventListener('mouseout', handleMouseOut, true);
    document.removeEventListener('click', handleClick, true);
    document.removeEventListener('keydown', handleKeyDown, true);
  }

  function showToast(msg) {
    let t = document.getElementById('aipp-picker-toast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'aipp-picker-toast';
      t.style.position = 'fixed';
      t.style.top = '16px';
      t.style.left = '50%';
      t.style.transform = 'translateX(-50%)';
      t.style.background = '#fffdf9';
      t.style.color = '#0f0f11';
      t.style.border = '1.5px solid #e8ddd4';
      t.style.padding = '12px 20px';
      t.style.borderRadius = '12px';
      t.style.fontSize = '12px';
      t.style.fontWeight = '700';
      t.style.zIndex = '9999999';
      t.style.boxShadow = '0 8px 24px rgba(26,25,24,0.12), 0 2px 0 #e0d4c8';
      t.style.fontFamily = 'sans-serif';
      document.body.appendChild(t);
    }
    t.innerHTML = msg;
    t.style.display = 'block';
  }

  function hideToast() {
    const t = document.getElementById('aipp-picker-toast');
    if (t) t.style.display = 'none';
  }

  function handleMouseOver(e) {
    if (!isPickerActive) return;
    e.stopPropagation();
    if (currentHoverTarget) currentHoverTarget.classList.remove('aipp-picker-hover');
    currentHoverTarget = e.target;
    currentHoverTarget.classList.add('aipp-picker-hover');
  }

  function handleMouseOut(e) {
    if (!isPickerActive) return;
    e.stopPropagation();
    if (e.target) e.target.classList.remove('aipp-picker-hover');
  }

  function handleClick(e) {
    if (!isPickerActive) return;
    e.preventDefault();
    e.stopPropagation();

    const selectedElement = e.target;
    disablePicker();

    // Lock the element
    lockElementWithPaywall(selectedElement, targetLockPrice);
  }

  function handleKeyDown(e) {
    if (e.key === 'Escape' && isPickerActive) {
      disablePicker();
    }
  }

  function lockElementWithPaywall(el, price) {
    // Prevent locking body or html document directly
    if (el === document.body || el === document.documentElement) return;

    // Generate paywall container wrapping selected element
    const container = document.createElement('div');
    container.style.position = 'relative';
    container.style.display = 'block';
    container.style.width = '100%';

    if (el.parentNode && el.parentNode.nodeType === 1) {
      el.parentNode.insertBefore(container, el);
      container.appendChild(el);
    } else {
      return;
    }

    el.classList.add('aipp-locked-element');

    // Create Paywall Badge with addEventListener (CSP compliant)
    const badge = document.createElement('div');
    badge.className = 'aipp-paywall-overlay-badge';
    badge.innerHTML = `🏷️ Unlock Content ($${price.toFixed(2)})`;
    
    badge.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      window.open(`https://aipp.dev/checkout.html?price=${price}`, '_blank');
    });

    container.appendChild(badge);

    // Generate HTML Embed Snippet & Copy to Clipboard for Editors (Blogger / WordPress)
    const rawContentHtml = el.outerHTML;
    const embedHtml = `<div data-aipp-src="demo" data-aipp-price="${price}">${rawContentHtml}</div>\n<script src="https://aipp.dev/paywall.js"></script>`;

    navigator.clipboard.writeText(embedHtml).then(() => {
      showToast(`🏷️ Smart Tag Attached! HTML tag code copied to clipboard. Paste anywhere.`);
      setTimeout(hideToast, 4000);
    }).catch(() => {
      showToast(`🏷️ Tagged element on page for $${price.toFixed(2)}!`);
      setTimeout(hideToast, 3000);
    });
  }

})();
